#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "lib.h"

#define HOST "127.0.0.1"
#define PORT 10001
#define MOD 64
#define DEFAULT_TIMEOUT 5000
#define MAX 1000

int main(int argc, char** argv) {
    init(HOST, PORT);
    
    msg *send = NULL;
    msg *recv = NULL;

    char current_seq = -1;
    int nr=0;
    int timeout = 0;
    int fd[MAX];
    int index=0;
    char *nume = malloc(1000);
    char *info = malloc(251); 
	int primul = 1;

while(1){
		//asteptam Send-Init.Asteptam 3 *DEFAULT_TIMEOUT
		if(primul == 1) {
			recv = receive_message_timeout(3*DEFAULT_TIMEOUT);
			primul = 0;
		}
		//asteptam alt mesaj diferit de SEND-INIT
		else
			recv = receive_message_timeout(DEFAULT_TIMEOUT);
		//nr de timeouturi consecutive	
label:	nr = 0;
		//cat timp mesajul primit e corupt sau ce am primit nu are nr de seq mai mare cu 1 mod 64 fata de numarul local de seq
		while(check(recv) == -1 || recv->payload[2] != (current_seq+1)%64){
			//daca am primit 3 timeouri consecutive inchid
				if(nr==3){
					return -1;
				}
				//daca am primit timeout 
				else if(recv == NULL){

					//incrementez nr de timeouturi
					nr++;
					
					//printf("\n[.receiver] Am primit mesaj  null\n");
					//printf("[.receiver] Retrimit mesajul anterior MSG[%hhi]\n\n",send->payload[2]);
				}
				
				//altfel
				else{
						//resetez nr de timeouturi
						nr = 0;
						
						//printf("\n[.receiver] Am primit MSG[%hhi] gresit de tipul %c\n",recv->payload[2],recv->payload[3]);

						//daca primesc un pachet cu seq mai mare cu 1 decat ce am trimis eu ultima data maresc current_seq si trimit un NACK cu current_seq actualizat
						if((current_seq+1)%64 == recv->payload[2]){
							current_seq = (current_seq+2)%64;
							send = prepare_msg('N',NULL,0,current_seq);
						}
						
						//printf("[.receiver] Trimit NACK[%hhi],iar nr din contor este %d \n\n",send->payload[2],nr);
					}

				send_message(send);
				recv = receive_message_timeout(DEFAULT_TIMEOUT);
				
			}
			 //daca ajung mai jos am primit mesajul pe care il asteptam
			

			//printf("\n[.kreceiver] MSG[%hhi]\n",recv->payload[2]);
			

			//scrierea in fisiere,in functie de tipul pachetului primit;

			if(recv->payload[3] == 'F'){
	            strcpy(nume,"recv_");
	            memcpy(nume+5,recv->payload+4,recv->len -7);
	            fd[index] = open(nume,O_RDWR|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IROTH);
	        }
        	else if(recv->payload[3] == 'D'){
            	memcpy(info,recv->payload+4,recv->len - 7);
            	write(fd[index],info,recv->len-7);
        	}

	        else if(recv->payload[3] == 'Z'){
	            close(fd[index]);
	            index++;
	        }
	        else if(recv->payload[3] == 'B'){
	        }
	    
	        //daca ce am primit e de tip Send-Init
			if(recv->payload[3] == 'S'){
				//actualizam timeout
				timeout = 1000*recv->payload[5];
				
				send = recv;
				set_type(send,'Y');
				//actualizez current_seq daca ce am primit e ce ma asteptam sa primesc,altfel voi trimite pachetul curent
				if((current_seq+1)%64 == recv->payload[2])
					current_seq = (recv->payload[2]+1)%64;
				set_seq(send,current_seq);
			}	
			//daca e un pachet de alt tip decat SEND-init
			else{
				//actualizez current_seq daca ce am primit e ce ma asteptam sa primesc,altfel voi trimite pachetul curent
				if((current_seq+1)%64 == recv->payload[2])
					current_seq = (recv->payload[2]+1)%64;
				
				send = prepare_msg('Y',NULL,0,current_seq);
			}
	
			nr=0;
			while(1){
					//daca am primit 3 timeouturi consecutive ies
					if(nr == 3)
						return -1;
					
					//printf("\n[kreceiver] ACK[%hhi] no %d\n",send->payload[2],nr);
					
					send_message(send);
					recv = receive_message_timeout(DEFAULT_TIMEOUT);
		
					//daca nu am primit timeout
					if(recv !=NULL){
						//resetez contorul
						nr = 0 ;
						//printf("[.kreceiver] recv->payload[2] == (current_seq+1)mod64  : %hhi == %hhi\n",recv->payload[2],(current_seq+1)%64);
					}
					//altfel incrementez nr de timeouturi
					else
						nr++;

					//daca ce am primit e corupt ma intorc la inceputul whileului,unde se reseteaza nr la 0
					if(check(recv)== -1){
						goto label;
					}

					//daca mesajul e corect si e ce ma asteptam sa primesc
					if(check(recv) == 1 && recv->payload[2] == (current_seq+1)%64){	
						//daca am primit un pachet final de tip 'B'
						if(recv->payload[2] == 'B')
							return 0;
						//altfel ma intorc la inceputul while ului unde se reseteaza nr la 0
						else 
							goto label;
					}
			}	
	}
}
	



