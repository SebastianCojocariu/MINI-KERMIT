#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "lib.h"

#define HOST "127.0.0.1"
#define PORT 10000
#define DEFAULT_TIMEOUT 5000
#define MOD 64
#define MAX 3000


int main(int argc,char **argv){
	init(HOST, PORT);

    msg *send = malloc(sizeof(msg));
    msg *recv = malloc(sizeof(msg));
    msg vector_mesaje[MAX];
    
    char *info = malloc(251);
    int fd[MAX];
    int dimensiuni[MAX];
    int nr_fisiere = argc-1;
    int current_seq = 0 ;  
    
    //setez dimensiunile fisierelor care vor fi transmise in vectorul dimensiuni[] si deschis fisierele cu open,memorand FD in vectorul fd[].
    for(int i=0;i<nr_fisiere;i++){
        struct stat st;
        fd[i] = open(argv[i+1],O_RDWR);
        stat(argv[i+1],&st);
        dimensiuni[i] = st.st_size;
    }

    int index=0,i=0;
    int ok=1;
    int nr=0;
   // printf("numarul de nr_fisiere %d: %d\n",nr_fisiere,dimensiuni[0]);
   
 	
    //completam vectorul de mesaje
 	index = 0;
    //construim pachetul de SEND-INIT.
 	vector_mesaje[index++] = *(prepare_msg('S',NULL,0,0));	
 

    for(i=0;i<nr_fisiere;i++){
                	if(ok==1){
                    	vector_mesaje[index++] = *(prepare_msg('F',argv[i+1],strlen(argv[i+1]),current_seq));
                    	ok=0;
                	}

                	while(dimensiuni[i]>0){
                    	int nr_octeti_cititi = read(fd[i],info,250);
                    	dimensiuni[i] -= nr_octeti_cititi;
                    	vector_mesaje[index++] = *(prepare_msg('D',info,nr_octeti_cititi,current_seq));
                    
                    }
                    
                    vector_mesaje[index++] = *(prepare_msg('Z',NULL,0,current_seq));
                    ok=1;
    }
  
    vector_mesaje[index++] = *prepare_msg('B',NULL,0,current_seq);

    nr=0;         
    i= 0;

//am terminat de completat vectorul de mesaje


    while(nr<3){	
    label:  //daca am ajuns la sfarsitul vectorului de mesaje dam exit
            if(i == index)
                return 1;	
            //printf("\n\nINCEP trimiterea pachetului de pe pozitia %d \n\n",i);
            nr=0;
    		send = vector_mesaje+i;
    		set_seq(send,current_seq);
           // printf("[.sender] trimit MSG[%hhi] de tipul %c\n",send->payload[2],send->payload[3]);
    		send_message(send);
    		recv = receive_message_timeout(DEFAULT_TIMEOUT);
    		
            //cat timp ce primim e null sau e NACK
            while(recv == NULL || recv->payload[3] == 'N'){
                //daca nr de timeouturi e 3 dam exit
    			if(nr==3)
    				return -1;
                //daca am primit timeout incrementam nr
    			if(recv == NULL){
    				//printf("[.sender] am primit null\n");
    				nr++;	
    			}
    			
                //daca am primit NACK	
    			else if(recv->payload[3] == 'N'){
                    nr=0;
    				//printf("[.sender] am primit NACK[%hhi] \n",recv->payload[2]);
                    //daca ce primesc e ce ma asteptam sa primesc actualizam current_seq
                    if((current_seq+1)%64 == recv->payload[2])
                        current_seq = (current_seq+2)%64; 
    				    set_seq(send,current_seq);
                       // printf("[.sender] Retrimit MSG[%hhi] de tipul %c\n",send->payload[2],send->payload[3]);
    			}
                
                send_message(send);
                recv = receive_message_timeout(DEFAULT_TIMEOUT);
            }
            
            //daca ajuns aici inseamna ca am primit ACK
            if(recv->payload[3] == 'Y'){
    			//printf("[.sender] am primit ACK[%hhi] \n",recv->payload[2]);
                //daca ce primesc e ce ma asteptam sa primesc modific current_seq si incrementez i
                //adica pozitia din vectorul de mesaje.
                if((current_seq+1)%64 == recv->payload[2]){
    				current_seq = (recv->payload[2]+1)%64;
                     i++;
                }
                //daca am ajuns la sfarsitul vectorului de mesaje dam return 0
    			if(i == index)
    				return 0;
                //daca nr de timeouturi e <3 sarim la inceputul while-ului
    			if(nr<3) 
    				goto label;
    							
    		}				
    }

}
